import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';

const GET_MODEL = gql\`
  query($modelId: ID!) {
    model(id: $modelId) {
      id
      name
      image
      type
      description
      brand { name }
      price
    }
  }
\`;

function ModelDetailPage() {
  const { modelId } = useParams();
  const navigate = useNavigate();
  const { loading, error, data } = useQuery(GET_MODEL, {
    variables: { modelId }
  });

  if (loading) return <div>Loading model details...</div>;
  if (error) return <div>Error: {error.message}</div>;

  const model = data.model;

  return (
    <div style={{ padding: 24, maxWidth: 600, margin: '0 auto' }}>
      <button onClick={() => navigate(-1)} style={{ marginBottom: 16 }}>← Back</button>
      <img src={model.image} alt={model.name} style={{ width: '100%', borderRadius: 10, marginBottom: 16 }} />
      <h1>{model.name}</h1>
      <h3>{model.brand.name} – {model.type}</h3>
      <div style={{ fontSize: 22, margin: '8px 0' }}>${model.price}</div>
      <p style={{ marginTop: 12 }}>{model.description}</p>
    </div>
  );
}

export default ModelDetailPage;

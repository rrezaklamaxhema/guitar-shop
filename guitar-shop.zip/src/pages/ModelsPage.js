import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';

const GET_BRAND_MODELS = gql\`
  query($brandId: ID!, $name: String, $type: String, $offset: Int, $limit: Int) {
    brand(id: $brandId) {
      id
      name
      models(name: $name, type: $type, offset: $offset, limit: $limit) {
        id
        name
        type
        image
      }
      modelTypes
      modelsCount(name: $name, type: $type)
    }
  }
\`;

const PAGE_SIZE = 6;

function ModelsPage() {
  const { brandId } = useParams();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);

  const { loading, error, data } = useQuery(GET_BRAND_MODELS, {
    variables: {
      brandId,
      name: search.length > 0 ? search : undefined,
      type: type || undefined,
      offset: (page - 1) * PAGE_SIZE,
      limit: PAGE_SIZE,
    },
    fetchPolicy: 'cache-and-network',
  });

  if (loading) return <div>Loading models...</div>;
  if (error) return <div>Error: {error.message}</div>;

  const models = data.brand.models;
  const types = data.brand.modelTypes;
  const total = data.brand.modelsCount;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div style={{ padding: 24 }}>
      <button onClick={() => navigate(-1)} style={{ marginBottom: 12 }}>← Back</button>
      <h1>{data.brand.name} Models</h1>
      <div style={{ display: 'flex', gap: 12, margin: '12px 0' }}>
        <input
          type="text"
          placeholder="Search models..."
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1); }}
        />
        <select
          value={type}
          onChange={e => { setType(e.target.value); setPage(1); }}
        >
          <option value="">All Types</option>
          {types.map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>
      <div style={{ display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))' }}>
        {models.length === 0 && <div>No models found.</div>}
        {models.map(model => (
          <div key={model.id} style={{ border: '1px solid #ddd', borderRadius: 10, padding: 12, cursor: 'pointer' }}
            onClick={() => navigate(`/models/${model.id}`)}
          >
            <img src={model.image} alt={model.name} style={{ width: '100%', borderRadius: 8, marginBottom: 8 }} />
            <h3 style={{ margin: 0 }}>{model.name}</h3>
            <span style={{ color: '#666' }}>{model.type}</span>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 24 }}>
        <button onClick={() => setPage(page - 1)} disabled={page === 1}>Previous</button>
        <span style={{ margin: '0 16px' }}>Page {page} of {totalPages}</span>
        <button onClick={() => setPage(page + 1)} disabled={page === totalPages}>Next</button>
      </div>
    </div>
  );
}

export default ModelsPage;

import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { useNavigate } from 'react-router-dom';

const GET_BRANDS = gql\`
  query {
    brands {
      id
      name
    }
  }
\`;

function BrandsPage() {
  const { loading, error, data } = useQuery(GET_BRANDS);
  const navigate = useNavigate();

  if (loading) return <div>Loading brands...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div style={{ padding: 24 }}>
      <h1>Guitar Brands</h1>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {data.brands.map((brand) => (
          <li key={brand.id} style={{ margin: '12px 0' }}>
            <button
              style={{
                padding: 12, width: 250, textAlign: 'left', borderRadius: 8,
                border: '1px solid #ccc', background: '#f8f8fa', cursor: 'pointer',
                fontSize: 18
              }}
              onClick={() => navigate(\`/brands/\${brand.id}\`)}
            >
              {brand.name}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BrandsPage;

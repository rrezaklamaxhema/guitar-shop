import React from 'react';
import { ApolloProvider } from '@apollo/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import client from './apolloClient';
import BrandsPage from './pages/BrandsPage';
import ModelsPage from './pages/ModelsPage';
import ModelDetailPage from './pages/ModelDetailPage';

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <Routes>
          <Route path="/" element={<BrandsPage />} />
          <Route path="/brands/:brandId" element={<ModelsPage />} />
          <Route path="/models/:modelId" element={<ModelDetailPage />} />
        </Routes>
      </Router>
    </ApolloProvider>
  );
}

export default App;
